<?php

use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user1 = \App\User::create([
            'name' => 'admin',
            'email' => 'admin@app.com',
            'password' => bcrypt('123456789'),
            'phone' => '+201121184147',
            'country_id' => '1',
            'gender' => 'male',
            'profile' => 'avatarmale.png',
            'type' => 'admin',
            'phone_verified_at' => '2021-10-25 22:43:41' ,
        ]);

        $user2 = \App\User::create([
            'name' => 'admin1',
            'email' => 'admin1@app.com',
            'password' => bcrypt('123456789'),
            'phone' => '+201121184148',
            'country_id' => '1',
            'gender' => 'male',
            'profile' => 'avatarmale.png',
            'type' => 'admin',
            'phone_verified_at' => '2021-10-25 22:43:41' ,

        ]);

        $user3 = \App\User::create([
            'name' => 'admin2',
            'email' => 'admin2@app.com',
            'password' => bcrypt('123456789'),
            'phone' => '+201121184149',
            'country_id' => '1',
            'gender' => 'male',
            'profile' => 'avatarmale.png',
            'type' => 'admin',
            'phone_verified_at' => '2021-10-25 22:43:41' ,

        ]);



        $user1->attachRole('superadministrator');

        $user2->attachRole('affiliate');

        $user3->attachRole('vendor');


        \App\Cart::create([
            'user_id' => $user1->id,
        ]);

        \App\Cart::create([
            'user_id' => $user2->id,
        ]);

        \App\Cart::create([
            'user_id' => $user3->id,
        ]);



        $country = \App\Country::create(        [
            'name_ar' => 'مصر',
            'name_en' => 'Egypt',
            'code' => '002',
            'currency' => 'EGP',
            'image' => 'images/countries/dSroDy5KlCP8nU4H5eowlWxDuabJrVrBx47Jrdkf.png',
        ]);

        // $user = \App\User::find(2);

        \App\Balance::create([
            'user_id' => $user1->id,
            'available_balance' => 0,
            'outstanding_balance' => 0,
            'pending_withdrawal_requests' => 0,
            'completed_withdrawal_requests' => 0,
        ]);

        \App\Balance::create([
            'user_id' => $user2->id,
            'available_balance' => 0,
            'outstanding_balance' => 0,
            'pending_withdrawal_requests' => 0,
            'completed_withdrawal_requests' => 0,
        ]);

        \App\Balance::create([
            'user_id' => $user3->id,
            'available_balance' => 0,
            'outstanding_balance' => 0,
            'pending_withdrawal_requests' => 0,
            'completed_withdrawal_requests' => 0,
        ]);


        $cat1 = \App\Category::create([
            'name_ar' => 'ملابس',
            'name_en' => 'clothes',
            'description_ar' => 'sdfsdfsfsfsfsff',
            'description_en' => 'sdfsdfsdfsfsdfsdf',
            'country_id' => '1',
            'image' => 'YfZWQJjRdVz30MOxOFTRPyTV3Q6YjjKakSs6zFY9.jpg',
            'parent' => 'null',
            'profit' => '10',



        ]);


        $cat2 = \App\Category::create([
            'name_ar' => 'أحذية',
            'name_en' => 'shose',
            'description_ar' => 'sdfsdfsfsfsfsff',
            'description_en' => 'sdfsdfsdfsfsdfsdf',
            'country_id' => '1',
            'image' => 'uvpskAsfNxmUCgn2MycoR7JzrDWJkAnNl6L5c6Yf.jpg',
            'parent' => 'null',
            'profit' => '10',


        ]);


        $color1 = \App\Color::create([
            'color_ar' => 'أحمر',
            'color_en' => 'red',
            'hex'  =>  '#ff0d0d'


        ]);



        $color2 = \App\Color::create([
            'color_ar' => 'أسود',
            'color_en' => 'black',
            'hex'  =>  '#000000'


        ]);

        $color3 = \App\Color::create([
            'color_ar' => 'أخضر',
            'color_en' => 'green',
            'hex'  =>  '#00ff00'


        ]);


        $ship1 = \App\ShippingRate::create([
            'country_id' => '1',
            'city_ar' => 'القاهرة',
            'city_en' => 'cairo',
            'cost' => '50',


        ]);

        $ship2 = \App\ShippingRate::create([
            'country_id' => '1',
            'city_ar' => 'الجيزة',
            'city_en' => 'giza',
            'cost' => '40',


        ]);



        $size1 = \App\Size::create([
            'size_ar' => 'مقاس موحد',
            'size_en' =>  'One size'

        ]);

        $size2 = \App\Size::create([
            'size_ar' => 'L',
            'size_en' =>  'L'

        ]);

        $size3 = \App\Size::create([
            'size_ar' => 'XL',
            'size_en' =>  'XL'
        ]);




    }
}


