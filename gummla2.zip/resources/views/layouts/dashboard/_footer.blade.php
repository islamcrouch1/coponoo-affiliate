  <!-- /.content-wrapper -->
  <footer class="main-footer">

    <p>© 2021 Coponoo. All Rights Reserved - Developed By <a style="color: red" href="http://red-gulf.com/">RED</a> </p>
    {{-- <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 3.0.5
    </div> --}}
  </footer>
