<?php

use App\Product;
use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {


        $products = Product::all();

        foreach ($products as $product) {

            $product->categories()->attach($product->category_id);
        }
    }
}
